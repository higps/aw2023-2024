--4. 
-- Write SQL queries to create the following database.
--Note that phone number in the EMP table can only be 8 characters. SSN in the PERSON table can
--only be 11 characters. ZIP in the ADDRESS table can only be 4 characters. Explain any assumptions
--you make when creating the tables.

-- Here the EMP is a table with three primary keys. The idea is so that multiple people can live in the same hous, but divided
-- by their SSN number creating a unique combination, where you can sort by the indivudals SSN number, since it's the primary key there 
-- can't be duplicates of it, while they can share first names and addreses and cities and the like. The phone number in EMP must also be unique
-- Since 2 people can't share the same phone number in this database

CREATE TABLE PERSON (
    SSN VARCHAR(11) PRIMARY KEY,
    LAST_NAME VARCHAR(50) NOT NULL,
    FIRST_NAME VARCHAR(50) NOT NULL,
    MID_INT VARCHAR(50) NOT NULL
);

CREATE TABLE ADDRESS (
    ST_ADDR VARCHAR(50) PRIMARY KEY,
    CITY VARCHAR(50) NOT NULL,
    STATE VARCHAR(50) NOT NULL,
    ZIP VARCHAR(4) NOT NULL
);

CREATE TABLE EMP (
	PHONE INT UNIQUE,
    EMP_INFO VARCHAR REFERENCES PERSON(SSN),
    ADDR_INFO VARCHAR REFERENCES ADDRESS(ST_ADDR),
    PRIMARY KEY (PHONE, EMP_INFO, ADDR_INFO)
);
